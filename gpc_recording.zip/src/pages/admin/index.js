import LoginMain from "@/components/login/LoginMain";
import React from "react";

const index = () => {
  return <LoginMain />;
};

export default index;
