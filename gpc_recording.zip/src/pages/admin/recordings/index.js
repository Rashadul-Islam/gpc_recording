import RecordListMain from "@/components/recordList/RecordListMain";
import React from "react";

const index = () => {
  return (
    <div className="h-screen overflow-y-hidden">
      <RecordListMain />
    </div>
  );
};

export default index;
